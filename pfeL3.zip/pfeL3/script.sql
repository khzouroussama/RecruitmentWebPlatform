DROP DATABASE IF EXISTS recrutement2;
CREATE DATABASE recrutement2;
USE recrutement2;

CREATE TABLE IF NOT EXISTS Postes (
  numPost INTEGER AUTO_INCREMENT PRIMARY KEY ,
  nomPoste VARCHAR(200) ,
  TypePoste varchar(200),
  Discription VARCHAR(200),
  Specialite VARCHAR(200),
  Diplomes VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS Utilisateurs (
  id       VARCHAR(50) PRIMARY KEY,
  Email    VARCHAR(200) NOT NULL,
  mot_pass VARCHAR(50)  NOT NULL,
  role VARCHAR(200)  NOT NULL
);

CREATE TABLE IF NOT EXISTS EtatUtilisateur (
  id VARCHAR(50) PRIMARY KEY ,
  POST_CHOISIS INTEGER ,
  ETAT INTEGER ,
  CONSTRAINT fk_id_etat FOREIGN KEY (id) REFERENCES Utilisateurs(id),
  CONSTRAINT fk_nom_Poste FOREIGN KEY (POST_CHOISIS) REFERENCES Postes(numPost)
);

alter TABLE EtatUtilisateur ADD JUGE VARCHAR(30) ;
ALTER TABLE EtatUtilisateur DROP FOREIGN KEY fk_id_etat;
ALTER TABLE EtatUtilisateur DROP FOREIGN KEY fk_nom_Poste;
ALTER TABLE EtatUtilisateur DROP FOREIGN KEY fk_id_etat2;
ALTER TABLE EtatUtilisateur
  ADD CONSTRAINT fk_id_etat
FOREIGN KEY (id) REFERENCES Utilisateurs (id) ON DELETE CASCADE ;

ALTER TABLE EtatUtilisateur
  ADD CONSTRAINT fk_nom_Poste
FOREIGN KEY (POST_CHOISIS) REFERENCES Postes (numPost) ON DELETE CASCADE ;

ALTER TABLE EtatUtilisateur
  ADD CONSTRAINT fk_id_etat2
FOREIGN KEY (id) REFERENCES Utilisateurs (id) ON UPDATE CASCADE ;


CREATE TABLE IF NOT EXISTS InfoPerso (
  id     VARCHAR(50) PRIMARY KEY,
  nom    VARCHAR(200),
  prenom VARCHAR(200),
  date_n DATE ,
  lieu_n VARCHAR(200),
  fichierEN VARCHAR(200),
  fichierNAT varchar(200),
  CONSTRAINT fk_id FOREIGN KEY (id) REFERENCES Utilisateurs(id) on DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Diploms (
  numDip INTEGER auto_increment PRIMARY KEY ,
  id VARCHAR(50) ,
  typeDip VARCHAR(30),
  etablissDip VARCHAR(200),
  dateDip DATE,
  fichierDip VARCHAR(200),
  CONSTRAINT fk_id_dip FOREIGN KEY (id) REFERENCES Utilisateurs(id) on DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Experinces (
  numExp INTEGER auto_increment PRIMARY KEY ,
  id VARCHAR(50) ,
  etabEx VARCHAR(30),
  dateDebEx DATE,
  dateFinEx DATE,
  fichierDip VARCHAR(200),
  CONSTRAINT fk_id_exp FOREIGN KEY (id) REFERENCES Utilisateurs(id) on DELETE CASCADE
);



REPLACE INTO Postes VALUES (DEFAULT ,'Ingenieur','S_RECHERCHE','' ,'Informatique','master-diplôme d\'ingénieur');
REPLACE INTO Postes VALUES (DEFAULT ,'Technicien supérieur','S_RECHERCHE','','audiovisuel','technicien supérieur');
REPLACE INTO Postes VALUES (DEFAULT ,'Technicien supérieur','S_RECHERCHE','','Informatique','technicien supérieur');
REPLACE INTO Postes VALUES (DEFAULT ,'Traducteur','S_RECHERCHE','','','Licence-master');
REPLACE INTO Postes VALUES (DEFAULT ,'Infographique','S_RECHERCHE','Infographique','Infographique','Licence-master');
REPLACE INTO Postes VALUES (DEFAULT ,'RECHERCHE','RECHERCHE','','Informatique','Magister-Doctorat-Doctorat d\'etat');


/*  ADD RH USER */
INSERT INTO Utilisateurs VALUE ('rh','rh@rh.rh','rhrhrhrh','RH');

/* ADD ADMIN USER */
INSERT INTO Utilisateurs VALUE ('admin','admin@admin.rh','admin','ADMIN');




DROP TABLE IF EXISTS EtatPlateforme;
CREATE TABLE IF NOT EXISTS EtatPlateforme(
  numPL INTEGER primary key ,
  dateDebut DATE,
  dateFin DATE
);
REPLACE INTO EtatPlateforme VALUES(1,'2010-10-10','2015-5-5');
delete from EtatPlateforme;


SELECT * FROM Postes;
select * from EtatUtilisateur;
select * from Experinces;
select * from Diploms;
select * from Utilisateurs;
select * from InfoPerso;

select * from EtatPlateforme;