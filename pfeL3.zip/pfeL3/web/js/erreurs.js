/*
script qui contien la manipulation des cas d'erreur
 */
/*
*
* */
errIcon ="<i class=\"fas fa-info-circle\"></i>";
var dateDeb;


function initErrChamps() {
    var x = document.getElementsByClassName("errMsg") ;
    var y = document.getElementsByClassName("in");
    for(var i=0;i < x.length;i++)
        x[i].innerHTML =''

    for(var i=0;i < y.length;i++)
        y[i].className = y[i].className.replace(/redErr/g,'');

}

// fonction qui returne si un elt html est vide est colorer le en rouge
function inputErreur(elt , ErrMsg) {
    if (elt.value === ""){
        if (! /inputFile/g.test(elt.className))
            elt.className += " redErr";
        else if (/green/.test(elt.previousElementSibling.className)) return false;
        elt.nextElementSibling.innerHTML = errIcon + ErrMsg ;
        return true ;
    }
    return false ;
}

function inputsErreurs(ErrMsg) {
    initErrChamps();
    var x = document.getElementsByClassName("in") ;
    var nonRemplt = false;
    for(var i=0;i < x.length;i++)
        nonRemplt |= inputErreur(x[i],ErrMsg) ;
    return nonRemplt ;
}

function isEmail(s) {
    return /(.)+@(.)+\.(.)+/.test(s) ;
}

function inputErrMsgS(errBlocks,fonction) {
    initErrChamps();
    var err = false;
    for (var i = 0; i < errBlocks.length; i++)
        err |= (inputErreur(errBlocks[i]," Ce champs est obligatoire ") || fonction(errBlocks[i].id)  );
    return err ;
}



//fonction recoit id de elment input pour afficher l'erreur
function valideChampsInscription(id) {
    var err = false;
    var elt =document.getElementById(id);
    switch (id) {
        case "usrName" :
            break;
        case "aemail":
            if (!isEmail(elt.value)) {
                elt.nextElementSibling.innerHTML = errIcon + " inserer un address Email valide ";
                elt.className += " redErr";
                err = true;
            }
            break;
        case "pass1" :
            if (elt.value.length < 8) {
                elt.nextElementSibling.innerHTML = errIcon +" Mot de pass tres court ";
                elt.className += " redErr";
                err = true;
            }
            break;
        case "pass2":
            if (elt.value !== document.getElementById('pass1').value) {
                elt.nextElementSibling.innerHTML = errIcon + ' Mot de pass non identique';
                elt.className += " redErr";
                err = true;
            }
            break;
    }
    return err ;
}

function validateChampsInfoPerso(id) {
    var err = false;
    var elt =document.getElementById(id);
    switch (id) {
        case "nom":
            break;
        case "prenom":
            break;
        case "date_n":
            if (new Date(elt.value) >= Date.now()){
                elt.nextElementSibling.innerHTML = errIcon + ' Ce Date est non valide';
                elt.className += " redErr";
                err =true;
            }
            break;
        case "lieu_n":
            break;
        case "fichierEn":
            break;
        case "fichierNationalite":
            break;
    }
    return err;
}

function validateChampsDiploms(id) {
    var err = false;
    var elt =document.getElementById(id);

    if (id.startsWith("dateDip")){
        if (new Date(elt.value) >= Date.now()){
            elt.nextElementSibling.innerHTML = errIcon + ' inserer une date valide';
            elt.className += " redErr";
            err =true;
        }
    }
    return err ;
}

function validateChampsExperiences(id){
    var err = false;
    var elt =document.getElementById(id);

    if (id.startsWith("dateDebEx")){
        dateDeb=new Date(elt.value);
        if (dateDeb >= Date.now()){
            elt.nextElementSibling.innerHTML = errIcon + ' inserer une date valide';
            elt.className += " redErr";
            err =true;
        }
    }

    if (id.startsWith("dateFinEx")){
        if (new Date(elt.value) >= Date.now()){
            elt.nextElementSibling.innerHTML = errIcon + ' inserer une date valide';
            elt.className += " redErr";
            err =true;
        }else if (new Date(elt.value) <= dateDeb ) {
            elt.nextElementSibling.innerHTML = errIcon + ' date de fin doit etre apres la date de debut';
            elt.className += " redErr";
            err =true;
        }
    }

    return err ;
}



function valideChampsModifPass(id) {
    var err = false;
    var elt =document.getElementById(id);
    switch (id) {
        case "pass1" :
            if (elt.value.length < 8) {
                elt.nextElementSibling.innerHTML = errIcon +" Mot de pass tres court ";
                elt.className += " redErr";
                err = true;
            }
            break;
        case "pass2":
            if (elt.value !== document.getElementById('pass1').value) {
                elt.nextElementSibling.innerHTML = errIcon + ' Mot de pass non identique';
                elt.className += " redErr";
                err = true;
            }
            break;
    }
    return err ;
}

function valideChampsActive_pl(id) {

    var err = false;
    var elt =document.getElementById(id);

    if (id == "date_deb"){
        dateDeb=new Date(elt.value);
        if (dateDeb < new Date(new Date().getFullYear() ,new Date().getMonth(), new Date().getDate() )){
            elt.nextElementSibling.innerHTML = errIcon + ' inserer une date valide';
            elt.className += " redErr";
            err =true;
        }
    }

    if (id == "date_fin"){
        if (new Date(elt.value) <= Date.now()){
            elt.nextElementSibling.innerHTML = errIcon + ' inserer une date valide';
            elt.className += " redErr";
            err =true;
        }else if (new Date(elt.value) <= dateDeb ) {
            elt.nextElementSibling.innerHTML = errIcon + ' date de fin doit etre apres la date de debut';
            elt.className += " redErr";
            err =true;
        }
    }

    return err ;
}