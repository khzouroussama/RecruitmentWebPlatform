function ME_template(html_str , _ ) {

    return html_str.replace(/\${[^}]+}/g, function (match, o, s) {
        var s = eval(match.substr(2, match.length - 3));
        return s !== undefined ?s:"";
    })

}
