function d_GET(str) {
    return document.getElementById(str)
}
function date_diffrence(d1,d2) {
    return new  Date ( new Date(d2) - new Date(d1) );
}
function date_diffrence_DMY(d1, d2) {
    var dif = date_diffrence(d1,d2) ;
    return {
        d : dif.getUTCDate() -1,
        m : dif.getUTCMonth(),
        y : dif.getUTCFullYear() - 1970
    }
}
function date_diffrence_in_words(d1,d2) {
    var diff = date_diffrence_DMY(d1,d2);
    var str ="";
    if ( diff.y > 0 )  str +=  diff.y +" ans ";
    if ( diff.m > 0 )  str += (diff.y?"et ":"") + diff.m +" mois ";
    if ( diff.d > 0 )  str += (diff.m||diff.y?"et ":"") + diff.d +" jours .";
    return str;
}




// print function

function printRH({divId, title}) {
    let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');

    mywindow.document.write(`<html><head><title>${title}</title>    <link rel="stylesheet" href="/css/style.css"/>`);
    mywindow.document.write('</head><body >');
    mywindow.document.write('<br>');
    mywindow.document.write('<br>');
    mywindow.document.write('<h1 style="text-align: center">CENTRE DE RECHERCHE SUR L\'INFORMATION SCIENTIFIQUE ET TECHNIQUE </h1>');
    mywindow.document.write('<br>');
    mywindow.document.write('<br>');
    mywindow.document.write('<br>');
    mywindow.document.write(document.getElementById(divId).innerHTML);
    mywindow.document.write('<br>');
    mywindow.document.write('<br>');
    mywindow.document.write('<div> <h5 style="text-align: center;color: red"> Vous devez changez votre mot pass !</h5> </div>');

    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}




function printListeCands(list, title) {
    titles ={
       '1':'Liste des candidats acceptée',
       '2':'Liste des candidats refusée',
       '3':'Liste des candidats non traitée'
    } ;
    let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');

    mywindow.document.write(`<html><head><title>${titles[title]}</title>    <link rel="stylesheet" href="/css/style.css"/>`);
    mywindow.document.write('</head><body >');
    mywindow.document.write('<br>');
    mywindow.document.write('<br>');
    mywindow.document.write('<h5 style="text-align: center">CENTRE DE RECHERCHE SUR L\'INFORMATION SCIENTIFIQUE ET TECHNIQUE </h5>');
    mywindow.document.write(`<h2 style="text-align: center"> ${titles[title]}</h2>`);
    mywindow.document.write('<br>');
    mywindow.document.write('<table border="1px" width="90%" align="center"> <tr>  <th>nom</th><th>prenom</th><th>poste choisi</th>   </tr>');
    for (var i = 0; i < list.length; i++) {
        mywindow.document.write(`<tr align="center"><td>${list[i].infop.nom}</td><td>${list[i].infop.prenom}</td><td>${list[i].PostChoisis}</td>  </tr>`);
    }

    mywindow.document.write('</table>');
    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}