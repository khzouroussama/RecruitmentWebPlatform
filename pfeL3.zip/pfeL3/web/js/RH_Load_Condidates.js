var condidat_array = [];
var selected_condidat_by_postes;

var file_url_s = new Map();
var files_abbr = {
    "EN": "Extrais de naissance",
    "NAT": "Nationalité",
    "DIP": "Diplome",
    "EXP": "attestation d'Experience"
};
var path_corrector = s => s.replace(/\'/g, " ");

var X___RIEN_TEMPLATE___X = '<div class="display-5 text-center blue my-5 h3"> Aucune Resultat </div>';

var X_DIPLOMES_COMPOSANT_TEMPLATE_X = '\
     <div class="border border-info ouss-round-sm ouss-LgreyBG mt-1 p-1  row px-2">\
        <b class="blue col-md-8 ouss-center text-center ">${ _.elt.dips[_.j].typeDip}</b>\
        <button class="btn btn-outline-info col-md-4 ouss-center p-0 rounded-pill font-weight-bold" \
                onclick="//this.innerHTML=this.innerHTML?\'-\':\'+\';" \
                data-toggle="collapse" data-target="#info_dip_${_.i}${_.j}" aria-expanded="false" >+</button>\
        <!-- PLUS D INFORMATIONS-->\
        <div class="collapse m-2 container-fluid" id="info_dip_${_.i}${_.j}" data-parent="#DIPS${_.i}" >\
            <div class="row">\
                <div class="col-md-8 text-truncate">\
                    <p class="border border-info mb-3 p-0"></p>\
                    <b class="blue col-md-12 p-0">Etablissement</b>\
                    <p class="col-md-12 blue ml-3 p-0">${_.elt.dips[_.j].etablissDip}</p>\
                    <b class="blue col-md-12 p-0">Date de diplome</b>\
                    <p class="col-md-12 blue ml-3 p-0">  ${_.elt.dips[_.j].dateDip}</p>\
                </div>\
                <div class="col-md-4 ouss-center text-center ouss-clickable ouss-shad" onclick="getFichier(\'DIP\',\'${_.elt.dips[_.j].numDip}\',\' ${path_corrector(_.elt.dips[_.j].fichierDip)} \')">\
                    <i class="col-md-12 blue fas fa-file-alt" style="text-align:center;font-size: 30px"></i>\
                    <p class="col-md-12 blue text-truncate "">  ${_.elt.dips[_.j].fichierDip} </p>\
                </div>\
            </div>\
        </div>\
     </div>\
';

var X_EXPERIENCE_COMPOSANT_TEMPLATE_X = '\
     <div class="border border-info ouss-round-sm ouss-LgreyBG mt-1 p-1  row px-2">\
        <b class="blue col-md-8 ouss-center text-center ">${ _.elt.exps[_.j].etabEx}</b>\
        <button class="btn btn-outline-info col-md-4 ouss-center p-0 rounded-pill font-weight-bold" \
            onclick="//this.innerHTML=this.innerHTML===\'+\'?\'-\':\'+\';" \
        data-toggle="collapse" data-target="#info_exp_${_.i}${_.j}" aria-expanded="false" >+</button>\
        <!-- PLUS D INFORMATIONS-->\
        <div class="collapse m-2 container-fluid" id="info_exp_${_.i}${_.j}" data-parent="#EXPS${_.i}" >\
            <div class="row">\
            ${var x,y;}\
                <div class="col-md-8 text-truncate">\
                    <p class="border border-info mb-3 p-0"></p>\
                    <b class="blue col-md-12 p-0">Debut</b>\
                    <p class="col-md-12 blue ml-3 p-0">${x=_.elt.exps[_.j].dateDebEx}</p>\
                    <b class="blue col-md-12 p-0">Fin</b>\
                    <p class="col-md-12 blue ml-3 p-0">  ${y=_.elt.exps[_.j].dateFinEx}</p>\
                </div>\
                <div class="col-md-4 ouss-center text-center ouss-clickable ouss-shad" onclick="getFichier(\'EXP\',\'${_.elt.exps[_.j].numExp}\',\'${path_corrector(_.elt.exps[_.j].fichierAttEx)}\')">\
                    <i class="col-md-12 blue fas fa-file-alt" style="text-align:center;font-size: 30px"></i>\
                    <p class="col-md-12 blue text-truncate "">  ${//_.elt.exps[_.j].fichierAttEx} Voire</p>\
                </div>\
            </div>\
            <div class="row">                   \
                <p class="col border border-info mb-1 p-0 mx-5"></p>\
                <b class="col-md-12 text-center blue p-0">\
                    ${date_diffrence_in_words(x,y)}\
                </b>\
            </div>\
        </div>\
     </div>\
';

var X__CONDIDAT_COMPOSANT_TEMPLATE__X = '\
                <div class="round smallBlock" style="padding:10px 30px;margin-bottom: 10px"> \
                    <div class="row">\
                        <div class="col-sm-1 blue ouss-center" style="font-weight: bold">\
                            <i class="col-sm-12 fas fa-user-alt blue" style="font-size: 35px;"></i>\
                            <div class=" text-truncate">${_.elt.USERNAME}</div>\
                        </div>\
                        <div class="col-sm-3 ouss-center"> \
                            <b class="blue col-sm-12 ">Nom et Prenom </b>\
                            <div class="col-sm-12"> ${_.elt.infop.nom}  ${_.elt.infop.prenom}</div>\
                        </div>\
                        <div class="col ouss-center">\
                            <b class="blue col-sm-12"> Date et lieu de naissanse </b>\
                            <div class="col-sm-12">  ${_.elt.infop.date_n} ${_.elt.infop.lieu_n} </div>  \
                        </div>\
                        <div class="col-sm-3 ouss-center">\
                            <b class="blue col-sm-12"> PostChoisis </b>\
                            <div class="col-sm-12">  ${_.elt.PostChoisis}</div> \
                        </div>\
                        <div class="com-sm-2 ml-auto">\
                            <span class="icons ouss-center">\
                                <button class="btn btn-outline-info rounded-pill" data-toggle="collapse" data-target="#collapseExample${_.i}" \
                                aria-expanded="false" aria-controls="collapseExample" onclick="var clicked=!clicked">\
                                <!--onclick="afficheExtraInfoBtn(${_.i})">-->\
                                    <i class="icon1 far fa-arrow-alt-circle-down"></i>\
                                    <i class="icon2 fas fa-arrow-alt-circle-down" ></i>\
                                      Plus d\'information \
                                </button>\
                            </span> \
                        </div>\
                    </div>\
                    <div>\
                        <div id="collapseExample${_.i}" class="collapse smallBlockIN ouss-LgreyBG round rounded-top row mb-3 px-3 py-3">\
                            <!-- INFO PERSONELE -->\
                            <div class="col border ouss-round-sm mx-1 ouss-greyBG p-3 mb-2">\
                                <div class="col-sm-12 blue text-center mb-3"><h4>Informations Personeles</h4></div>\
                                <div class="ouss-center ml-3  ">\
                                    <b class="blue col-md-12 ">Extrait de Naissance</b>\
                                    <p class="blue col-md-12 ml-3 ouss-clickable ouss-shad" onclick="getFichier(\'EN\',\'${_.elt.USERNAME}\',\'${path_corrector(_.elt.infop.fichierExNai)}\')"><i class="fas fa-file-pdf"></i>  ${//_.elt.infop.fichierExNai} Voire fichier</p>\
                                    <b class="blue col-md-12">Nationalite</b>\n\
                                    <p class="blue col-md-12 ml-3 ouss-clickable ouss-shad" onclick="getFichier(\'NAT\',\'${_.elt.USERNAME}\',\'${path_corrector(_.elt.infop.fichierNationalite)}\')"><i class="fas fa-file-pdf"></i>  ${//_.elt.infop.fichierNationalite} Voire fichier</p>\
                                </div> \
                            </div>\
                            <!-- DIPLOMS-->\
                            <div class="col border ouss-round-sm mx-1 ouss-greyBG p-3 mb-2">\
                                    <div class="col-sm-12 blue text-center mb-3"><h4>Diplomes et Formations</h4></div>     \
                                    <div id="DIPS${_.i}" class="ouss-center container-fluid">                \
                                        ${ _.X_DIPLOMES_COMPOSANT_TEMPLATE_X }\
                                    </div> \
                            </div>\
                            <!-- EXPERIENCE-->\
                            <div class="col border ouss-round-sm mx-1 ouss-greyBG p-3 mb-2">\
                                    <div class="col-sm-12 blue text-center mb-3">\
                                    <h4>Experience professionnele</h4></div>     \
                                    <div id="EXPS${_.i}" class="ouss-center container-fluid">                \
                                        ${ _.X_EXPERIENCE_COMPOSANT_TEMPLATE_X }\
                                    </div> \
                            </div>\
                            <div class="col-12 ouss-light-border rounded-pill" style="background: #efefef"> \
                            <button class="ouss-stiker float-left ouss-light-border my-2 px-2 py-1 font-weight-bold" style="margin-top: 0.7rem !important;"><i class="fas fa-check-circle mr-2"></i>${_.elt.juge}</button> \
                            <form action="/RH/juger">\
                            <input name="user" type="hidden" value="${_.elt.USERNAME}" />\
                            <button type="submit" name="sbt" value="2" class="float-right btnSimple ouss-light-border w-auto roundRight p-1 px-2 ouss-blue-borderEFFECT"\
                                    style="font-size: 17px">\
                                <i class="fas fa-times "></i>\
                                refuser\
                            </button> \
                            <button type="submit" name="sbt" value="1" class="float-right btnSimple ouss-light-border w-auto roundLeft p-1 px-2 ouss-blue-borderEFFECT"\
                                style="font-size: 17px">\
                                 <i class="fas fa-check"></i>\
                                valider\
                            </button>\
                            </form>\
                            </div>\
                        </div>\
                        </div>\
                    </div>\
                </div>  ';
//


// recuperer la liste avec ajax
var http = new XMLHttpRequest();
http.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        condidat_array = JSON.parse(this.responseText);
        selected_condidat_by_postes = condidat_array;
        _build_condidats(condidat_array)
    }
};
//msg.innerHTML ="<span class='blue'>" + LoadingIcon +"VERIFICATION ... </span>";
http.open("GET", "/AjaxRecuperListeDesCondidat"+location.search, true);
http.send();

// FIN RECUPERATION

//============================================================
//============================================================
function _rebuild_condidats(condidat) {
    _clear_condidats();
    _build_condidats(condidat);
}

function _clear_condidats() {
    document.getElementById("contenu").innerHTML = "";
}

/***************************/
function _build_condidats(condidat) {

    if (condidat.length == 0) {
        var d_pere = document.createElement("div");
        d_pere.className = "container-fluid";
        d_pere.innerHTML = X___RIEN_TEMPLATE___X;
        document.getElementById("contenu").appendChild(d_pere);
    }

    for (var i = 0; i < condidat.length; i++) {
        var elt = condidat[i];
        /*-------------------
       |  Build the elments  |
       \___________________*/
        var d_pere = document.createElement("div");
        d_pere.className = "container-fluid";

        var diploms = "";
        var experiences = "";

        for (var j = 0; j < elt.dips.length; j++)
            diploms += ME_template(X_DIPLOMES_COMPOSANT_TEMPLATE_X, {"elt": elt, "i": i, "j": j});
        for (var j = 0; j < elt.exps.length; j++)
            experiences += ME_template(X_EXPERIENCE_COMPOSANT_TEMPLATE_X, {"elt": elt, "i": i, "j": j});


        d_pere.innerHTML =
            ME_template(X__CONDIDAT_COMPOSANT_TEMPLATE__X,
                {
                    X_DIPLOMES_COMPOSANT_TEMPLATE_X: diploms,
                    X_EXPERIENCE_COMPOSANT_TEMPLATE_X: experiences,
                    elt: elt,
                    i: i
                }
            );
        document.getElementById("contenu").appendChild(d_pere);
    }

}

//************************************************
//************************************************
//************************************************
function getFichier(type_fichier, id, file_name) {
    document.getElementById("ouss-pdf-nom").innerHTML = file_name;
    document.getElementById("ouss-pdf-type").innerHTML = files_abbr[type_fichier];
    affiche_fenetre();
    if (file_url_s.get(type_fichier + id) === undefined) {
        downloadFichier(type_fichier, id);
        document.getElementById("my_pdfReader").src = "/utils/TelechargementPage.html";
    } else document.getElementById("my_pdfReader").src = file_url_s.get(type_fichier + id);
}

// DOWNLOD IF NOT EXIST
// LES TYPES sont : EN/NAT/DIP/EXP
function downloadFichier(type_fichier, id) {
    var http = new XMLHttpRequest();
    http.responseType = "blob";
    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var lire_pdf = window.URL.createObjectURL(this.response);
            file_url_s.set(type_fichier + id, lire_pdf);
            document.getElementById("my_pdfReader").src = file_url_s.get(type_fichier + id);
        }
    };
    http.open("POST", "/agaxGetFile", true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.send("type=" + type_fichier + "&id=" + id);
}