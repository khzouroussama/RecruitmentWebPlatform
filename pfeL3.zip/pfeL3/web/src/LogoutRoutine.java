import Connections.UtilisateurOperations;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "LogoutRoutine")
public class LogoutRoutine extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.getSession().setAttribute("CONNECTED_USER",null);
        request.getSession().setAttribute("CONNECTED_USER_ROLE",null);
        request.getSession().setAttribute("CONDIDAT",null);
        request.getSession().setAttribute("COMPLETE_CONDIDATURE",Boolean.FALSE);

        request.getSession().setAttribute("tab", 0);

        response.sendRedirect("/index");

    }

}
