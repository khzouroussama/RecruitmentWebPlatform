import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ADMINGestionComptes")
public class ADMINGestionComptes extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
            if (AdminTools.isADMIN(request)){
                request.getSession().setAttribute("RHpos",3);
                request.getSession().setAttribute("USERS_COUNT_RH",UtilisateurOperations.pageCountRH());
                request.getSession().setAttribute("USERS_COUNT_CND",UtilisateurOperations.pageCountCND());

                int page = request.getParameter("page") == null ? 1 : Integer.parseInt(request.getParameter("page"));

                if (request.getParameter("role") == null )
                    request.getSession().setAttribute("USERS_PAGE",UtilisateurOperations.getUserPageCND(page));
                else {
                    if (request.getParameter("role").equals("CND"))
                            request.getSession().setAttribute("USERS_PAGE",UtilisateurOperations.getUserPageCND(page));
                    else
                            request.getSession().setAttribute("USERS_PAGE",UtilisateurOperations.getUserPageRH(page));
                }
                request.getRequestDispatcher("/WEB-INF/RH/ADMINgestionComptes.jsp").forward(request,response);
            }
            else
                response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
        else response.sendRedirect("/login");
    }

}

