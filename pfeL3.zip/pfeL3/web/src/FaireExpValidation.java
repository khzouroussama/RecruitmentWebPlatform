import Beans.CondidatBean;
import Beans.ExperienceBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.Condidat;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

@WebServlet(name = "FaireExpValidation")
@MultipartConfig
public class FaireExpValidation extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        CondidatBean condidatBean =(CondidatBean) request.getSession().getAttribute("CONDIDAT");

        long nbExp =(long) request.getSession().getAttribute("nbExp");

        switch (request.getParameter("sbt")){
            //AJOUTER UN Experiece

            case "ADD":
                //mis a jour apres l'ajout d'un diplome;
                for (int i = 1; i <= nbExp; i++)
                    Condidat.UpdateExperience(request,i, condidatBean);

                condidatBean.getExps().add(new ExperienceBean());

                request.getSession().setAttribute("nbExp",nbExp +1);
                System.out.println(request.getSession().getAttribute("nbExp") +" Experience");
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                break;
            // ON CLICK ON RETURN
            case "RETURN":
                request.getSession().setAttribute("tab",1);
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                break;

            case "END":
                boolean ERR = false ;
                HashMap<String,HashMap<String,String>> ERRS =new HashMap<>();
                ArrayList<ExperienceBean> EXPS = new ArrayList<>();

                for (int i = 1; i <= nbExp; i++) {
                    Condidat.UpdateExperience(request,i , condidatBean);

                    try {

                        if    (UtilisateurOperations.ajouterExperience(condidatBean.getExps().get( i - 1 )));
                        else  System.out.println("errAJOUTERDIPLOM");

                    } catch (ConnectionExeption connectionExeption) {
                        ERR =true ;
                        ERRS.put(String.valueOf(i),connectionExeption.getMsg_s());
                        connectionExeption.printStackTrace();
                    }
                }

                if (ERR){
                    request.getSession().setAttribute("errsExp",ERRS);
                    request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                }else {

                    UtilisateurOperations.soumettreChoix(
                            (String) request.getSession().getAttribute("CONNECTED_USER"),
                            ((CondidatBean) request.getSession().getAttribute("CONDIDAT")).getPostChoisis(),
                            2
                    );

                    ((CondidatBean) request.getSession().getAttribute("CONDIDAT"))
                            .setETAT_CONDIDATURE(2);

                    request.getSession().setAttribute("COMPLETE_CONDIDATURE",Boolean.TRUE);
                    request.getSession().setAttribute("tab",0);
                    response.sendRedirect("/index");
                }


                System.out.println("hiqsqdi");
                break;
        }
        if (request.getParameter("sbt").startsWith("DELETE")){
            int indice_supp =(Integer.parseInt(request.getParameter("sbt").replaceFirst("DELETE","")));

            UtilisateurOperations.supprimerExperience(
                    condidatBean.getExps().get(indice_supp).getNumExp()
            );
            condidatBean.getExps().remove(indice_supp);

            request.getSession().setAttribute("nbExp",nbExp -1);
            System.out.println(request.getSession().getAttribute("nbExp") +" remove experience");
            request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (!UtilisateurOperations.isPlateformeActif()){
            request.getRequestDispatcher("WEB-INF/nonActivePage.jsp").forward(request,response);
            return;
        }

        if(request.getSession().getAttribute("CONNECTED_USER_ROLE") != null )
            if (request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("CND"))
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
            else response.getWriter().println("<h1>ERREUR</h2> Cette Page est pour les condidates .. ");
        else{
            response.sendRedirect("/login");
        }
    }



}
