import Beans.CondidatBean;
import Beans.UtilisateurBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.Condidat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "LoginRoutine")
public class LoginRoutine extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        UtilisateurBean usr = (UtilisateurBean) request.getSession().getAttribute("usrLogin");
        try {
            UtilisateurBean ConnectedUSER;

            if ((ConnectedUSER = UtilisateurOperations.login(usr) ) != null) {
                request.getSession().setAttribute("login",Boolean.TRUE);
                //TODO  FISSIONEE LES 2
                request.getSession().setAttribute("CONNECTED_USER",ConnectedUSER.getId());
                request.getSession().setAttribute("CONNECTED_USER_ROLE",ConnectedUSER.getRole());

                if (ConnectedUSER.getRole().equals("CND")) {

                    CondidatBean condidatBean = UtilisateurOperations.getCondidatBean(ConnectedUSER.getId());

                    if (condidatBean != null) {
                        // initialiser
                        Condidat.init(condidatBean);
                        request.getSession().setAttribute("nbDip", (long) condidatBean.getDips().size());
                        request.getSession().setAttribute("nbExp", (long) condidatBean.getExps().size());
                        if (condidatBean.getDips().size() > 0 || condidatBean.getExps().size() > 0)
                            request.getSession().setAttribute("COMPLETE_CONDIDATURE", Boolean.TRUE);
                    } else{
                        condidatBean = new CondidatBean(){{ setETAT_CONDIDATURE(0); setUSERNAME(ConnectedUSER.getId());}};
                        // initialiser
                        Condidat.init(condidatBean);
                        request.getSession().setAttribute("nbDip", 0L);
                        request.getSession().setAttribute("nbExp", 0L);
                    }

                    request.getSession().setAttribute("CONDIDAT", condidatBean);
                    response.sendRedirect("/index");
                }else if ( ConnectedUSER.getRole().equals("RH") ||  ConnectedUSER.getRole().equals("ADMIN") )
                    response.sendRedirect("/RH/index?t=1");
            } else {
                request.getSession().setAttribute("login", Boolean.FALSE);
                response.sendRedirect("/login");
            }

        }//TODO cree UNE page de ERREUR
        catch (ConnectionExeption connectionExeption) {
            connectionExeption.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getSession().setAttribute("RHpos",0);
        request.getRequestDispatcher("WEB-INF/Login.jsp").forward(request,response);
    }
}
