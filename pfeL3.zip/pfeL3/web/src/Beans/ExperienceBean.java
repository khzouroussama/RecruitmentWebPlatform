package Beans;

import Connections.ConnectionExeption;
import Outils.BeanValidator;

import java.nio.file.Paths;
import java.util.HashMap;

public class ExperienceBean implements BeanValidator {
    private String numExp;
    private String USERNAME,etabEx,dateDebEx,dateFinEx,fichierAttEx;

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public String getEtabEx() {
        return etabEx;
    }

    public void setEtabEx(String etabEx) {
        this.etabEx = etabEx;
    }

    public String getDateDebEx() {
        return dateDebEx;
    }

    public void setDateDebEx(String dateDebEx) {
        this.dateDebEx = dateDebEx;
    }

    public String getDateFinEx() {
        return dateFinEx;
    }

    public void setDateFinEx(String dateFinEx) {
        this.dateFinEx = dateFinEx;
    }

    public String getFichierAttEx() {
        return fichierAttEx;
    }

    public void setFichierAttEx(String fichierAttEx) {
        this.fichierAttEx = fichierAttEx;
    }


    public String getNomFichier(){
        return  fichierAttEx != null ? Paths.get(fichierAttEx).getFileName().toString() : null;
    }

    @Override
    public String toString() {
        return "{" +
                "\"numExp\":\"" + numExp + '\"' +
                ", \"USERNAME\":\"" + USERNAME + '\"' +
                ", \"etabEx\":\"" + etabEx + '\"' +
                ", \"dateDebEx\":\"" + dateDebEx + '\"' +
                ", \"dateFinEx\":\"" + dateFinEx + '\"' +
                ", \"fichierAttEx\":\"" + getNomFichier() + '\"' +
                '}';
    }

    @Override
    public boolean jeSuisValide() throws ConnectionExeption {
        String icon = "<i class=\"fas fa-info-circle\"></i> " ;

        String s = icon + " Ce Champ est obligatiore ";
        boolean err = false;
        HashMap<String, String> errs = new HashMap<String, String>() {{
            put("etabEx"       , "");
            put("dateDebEx"    , "");
            put("dateFinEx"    , "");
            put("fichierAttEx" , "");
        }};

        if (getEtabEx().isEmpty()){
            errs.put("etabEx", s);
            err = true;
        }

        if (getDateDebEx().isEmpty()){
            errs.put("dateDebEx", s);
            err = true;
        }

        if (getDateFinEx().isEmpty()){
            errs.put("dateFinEx", s);
            err = true;
        }

        if (getFichierAttEx() == null){
            errs.put("fichierAttEx", s);
            err = true;
        }

        if (err) throw new ConnectionExeption(errs);

        return !err;
    }

    public String getNumExp() {
        return numExp;
    }

    public void setNumExp(String numExp) {
        this.numExp = numExp;
    }
}
