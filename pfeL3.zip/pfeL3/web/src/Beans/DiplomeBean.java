package Beans;

import Connections.ConnectionExeption;
import Outils.BeanValidator;

import java.nio.file.Paths;
import java.util.HashMap;

public class DiplomeBean implements BeanValidator {
    private String numDip;
    private String USERNAME, typeDip, etablissDip, dateDip, fichierDip;

    public String getTypeDip() {
        return typeDip;
    }

    public void setTypeDip(String typeDip) {
        this.typeDip = typeDip;
    }

    public String getEtablissDip() {
        return etablissDip;
    }

    public void setEtablissDip(String etablissDip) {
        this.etablissDip = etablissDip;
    }

    public String getDateDip() {
        return dateDip;
    }

    public void setDateDip(String dateDip) {
        this.dateDip = dateDip;
    }

    public String getFichierDip() {
        return fichierDip;
    }

    public void setFichierDip(String fichierDip) {
        this.fichierDip = fichierDip;
    }

    public String getNomFichier() {
        return fichierDip != null ? Paths.get(fichierDip).getFileName().toString() : null;
    }


    @Override
    public String toString() {
        return "{" +
                "\"numDip\":\"" + numDip + '\"' +
                ", \"USERNAME\":\"" + USERNAME + '\"' +
                ", \"typeDip\":\"" + typeDip + '\"' +
                ", \"etablissDip\":\"" + etablissDip + '\"' +
                ", \"dateDip\":\"" + dateDip + '\"' +
                ", \"fichierDip\":\"" + getNomFichier() + '\"' +
                '}';
    }

    @Override
    public boolean jeSuisValide() throws ConnectionExeption {
        String icon = "<i class=\"fas fa-info-circle\"></i> ";

        String s = icon + " Ce Champ est obligatiore ";
        boolean err = false;
        HashMap<String, String> errs = new HashMap<String, String>() {{
            put("typeDip", "");
            put("etablissDip", "");
            put("dateDip", "");
            put("fichierDip", "");
        }};

        if (typeDip.isEmpty()) {
            errs.put("typeDip", s);
            err = true;
        }

        if (etablissDip.isEmpty()) {
            errs.put("etablissDip", s);
            err = true;
        }

        if (dateDip.isEmpty()) {
            errs.put("dateDip", s);
            err = true;
        }

        if (fichierDip == null) {
            errs.put("fichierDip", s);
            err = true;
        }

        if (err) throw new ConnectionExeption(errs);

        return !err;
    }


    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public String getNumDip() {
        return numDip;
    }

    public void setNumDip(String numDip) {
        this.numDip = numDip;
    }
}
