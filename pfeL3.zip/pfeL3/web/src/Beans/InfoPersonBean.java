package Beans;

import Connections.ConnectionExeption;
import Outils.BeanValidator;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class InfoPersonBean implements BeanValidator {
    private String USERNAME,nom,prenom,date_n,lieu_n;
    private String fichierExNai;
    private String fichierNationalite;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getDate_n() {
        return date_n;
    }

    public void setDate_n(String date_n) {
        this.date_n = date_n;
    }

    public String getLieu_n() {
        return lieu_n;
    }

    public void setLieu_n(String lieu_n) {
        this.lieu_n = lieu_n;
    }

    public String getFichierExNai() {
        return fichierExNai;
    }

    public void setFichierExNai(String fichierExNai) {
        this.fichierExNai = fichierExNai;
    }

    public String getFichierNationalite() {
        return fichierNationalite;
    }

    public void setFichierNationalite(String fichierNationalite) {
        this.fichierNationalite = fichierNationalite;
    }


    public String getNomFichierExNai(){
        return  (fichierExNai != null) ? Paths.get(fichierExNai).getFileName().toString() : null;
    }

    public String getNomFichierNationalite(){
        return  (fichierNationalite != null) ? Paths.get(fichierNationalite).getFileName().toString() : null;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    @Override
    public String toString() {
        return "{" +
                "\"USERNAME\":\"" + USERNAME + '\"' +
                ", \"nom\":\"" + nom + '\"' +
                ", \"prenom\":\"" + prenom + '\"' +
                ", \"date_n\":\"" + date_n + '\"' +
                ", \"lieu_n\":\"" + lieu_n + '\"' +
                ", \"fichierExNai\":\"" + getNomFichierExNai() + '\"' +
                ", \"fichierNationalite\":\"" + getNomFichierNationalite() + '\"' +
                '}';
    }

    @Override
    public boolean jeSuisValide() throws ConnectionExeption {
        String icon = "<i class=\"fas fa-info-circle\"></i> " ;

        String s = icon + " Ce Champ est obligatiore ";
        boolean err = false;
        HashMap<String, String> errs = new HashMap<String, String>() {{
            put("nom", "");
            put("prenom", "");
            put("date_n", "");
            put("lieu_n", "");
            put("fichierEN", "");
            put("fichierNationalite", "");
        }};

        if (nom == null){
            errs.put("nom",s);
            err =true ;
        }else if (nom.isEmpty()){
            errs.put("nom",s);
            err =true ;
        }

        if (prenom == null){
            errs.put("prenom",s);
            err =true ;
        }else if (prenom.isEmpty()){
            errs.put("prenom",s);
            err =true ;
        }

        if (date_n.isEmpty()){
            errs.put("date_n",s);
            err =true ;
        }else {
            try {
                Date dateN =DateFormat.getDateInstance(DateFormat.SHORT,Locale.CANADA)
                        .parse(date_n);

                if ( dateN.before(new Date(0,0,0)) || dateN.after(new Date())){
                    errs.put("date_n",icon+" se Date invalide  ");
                    err =true ;
                }else if (new Date().getYear() - dateN.getYear() < 18){ //verifier que plus que 18ans
                    errs.put("date_n",icon+" vous devez etre plus que 18 ans");
                    err =true ;
                }

            } catch (ParseException e) {
                errs.put("date_n",icon+" Format de Date invalide");
                err =true ;
                e.printStackTrace();
            }


        }


        if (lieu_n.isEmpty()){
            errs.put("lieu_n",s);
            err =true ;
        }

        if (fichierExNai == null){
            errs.put("fichierEN",s);
            err =true ;
        }else if (fichierExNai.isEmpty()){
            errs.put("fichierEN",s);
            err =true ;
        }


        if (getFichierNationalite() == null){
            errs.put("fichierNationalite",s);
            err =true ;
        }else if (getFichierNationalite().isEmpty()){
            errs.put("fichierNationalite",s);
            err =true ;
        }

        if (err) throw new ConnectionExeption(errs);
        return !err;
    }
}
