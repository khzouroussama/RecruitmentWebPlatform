package Beans;

import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.BeanValidator;

import java.util.Arrays;
import java.util.HashMap;

public class PostBean implements BeanValidator {


    final static HashMap<String,String> dip_nums = new HashMap<String, String>(){{
        put("Baccalauréat","1");
        put("technicien supérieur","2");
        put("Licence","3");
        put("master","4");
        put("diplôme d'ingénieur","5");
        put("Magister","6");
        put("Doctorat","7");
        put("Doctorat d'etat","8");
    }};

  public static PostBean getPosteById(String id) {

      for (int i = 0; i < POSTES_SOUTIEN_RECHERCHE.length; i++) {
          if (id.equals( POSTES_SOUTIEN_RECHERCHE[i].numPoste) )
              return POSTES_SOUTIEN_RECHERCHE[i];
      }

      for (int i = 0; i < POSTES_RECHERCHE.length; i++) {
          if (id.equals( POSTES_RECHERCHE[i].numPoste) )
              return POSTES_RECHERCHE[i];
      }
      System.out.println("getPosteById ----> ERRRR");
      return null;
  }


  public enum TYPE_POSTE { S_RECHERCHE, RECHERCHE }


    public static PostBean[] POSTES_SOUTIEN_RECHERCHE = UtilisateurOperations.getPostes(TYPE_POSTE.S_RECHERCHE);

    public static PostBean[]      POSTES_RECHERCHE    = UtilisateurOperations.getPostes(TYPE_POSTE.RECHERCHE) ;



    private String numPoste;
    private String nomPoste,Discription,Specialite;
    private TYPE_POSTE typePost ;
    private String[] Diploms;

    public String getNomPoste() {
        return nomPoste;
    }



    public void setNomPoste(String nomPoste) {
        this.nomPoste = nomPoste;
    }

    public String getDiscription() {
        return Discription;
    }

    public void setDiscription(String discription) {
        Discription = discription;
    }

    public String getSpecialite() {
        return Specialite;
    }

    public void setSpecialite(String specialite) {
        Specialite = specialite;
    }

    public String[] getDiploms() {
        return Diploms;
    }
    public String getDipsString(){ return String.join("-",Diploms);}
    public String getDipsStringNUM(){
        String[] tmp = getDiploms().clone();
        for (int i = 0; i < tmp.length; i++) {
            tmp[i] = dip_nums.get(tmp[i]);
        }
        return String.join("-",tmp);
    }

    public void setDiploms(String[] diploms) {
        Diploms = diploms;
    }

    public void setTypePost(TYPE_POSTE typePost) {
      this.typePost = typePost;
    }

    public TYPE_POSTE getTypePost() {
      return typePost;
    }


    public String getNumPoste() {
      return numPoste;
    }
    public void setNumPoste(String numPoste) {
      this.numPoste = numPoste;
    }

  @Override
  public String toString() {
    return "{" +
            "numPoste=" + numPoste +
            ", nomPoste='" + nomPoste + '\'' +
            ", Discription='" + Discription + '\'' +
            ", Specialite='" + Specialite + '\'' +
            ", typePost=" + typePost +
            ", Diploms=" + (Diploms == null ? null : Arrays.asList(Diploms)) +
            '}'+'\n';
  }


    @Override
    public boolean jeSuisValide() throws ConnectionExeption {
        String icon = "<i class=\"fas fa-info-circle\"></i> " ;

        String s = icon + " Ce Champ est obligatiore ";
        boolean err = false;
        HashMap<String, String> errs = new HashMap<String, String>() {{
            put("numPoste", "");
            put("nomPoste", "");
            put("typePoste", "");
            put("description", "");
            put("specialite", "");
            put("diploms", "");
        }};

        if (nomPoste == null){
            errs.put("nomPoste",s);
            err =true ;
        }else if (nomPoste.isEmpty()){
            errs.put("nomPoste",s);
            err =true ;
        }

        if (typePost == null){
            errs.put("typePost",s);
            err =true ;
        }

        if (getSpecialite() == null){
            errs.put("specialite",s);
            err =true ;
        }else if (getSpecialite().isEmpty()){
            errs.put("specialite",s);
            err =true ;
        }

        if (err) throw new ConnectionExeption(errs);
        return !err;
    }

}
