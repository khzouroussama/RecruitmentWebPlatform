package Beans;

import Connections.ConnectionExeption;
import Outils.BeanValidator;

import java.io.Serializable;
import java.util.HashMap;

public class UtilisateurBean implements Serializable, BeanValidator {

    private String id, emaila,role, pass ,pass2;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
        System.out.println(this.id);
    }

    public String getEmaila() {
        return emaila;
    }

    public void setEmaila(String emaila) {
        this.emaila = emaila;
        System.out.println(this.emaila);
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getPass2() {
        return pass2;
    }

    public void setPass2(String pass2) {
        this.pass2 = pass2;
    }

    public boolean jeSuisValide() throws ConnectionExeption {
        String icon = "<i class=\"fas fa-info-circle\"></i> " ;

        String s = icon + " Ce Champ est obligatiore ";
        boolean err = false;
        HashMap<String, String> errs = new HashMap<String, String>() {{
            put("id", "");
            put("emaila", "");
            put("pass", "");
            put("pass2", "");
        }};

        if (id == null) {
            errs.put("id", s);
            err = true;
        }

        if (emaila == null) {
            errs.put("emaila", s);
            err = true;
        } else if (!emaila.matches(".+@.+\\..+")) {
            errs.put("emaila", icon +" inserez un address valide");
            err = true;
        }

        if (pass == null) {
            errs.put("pass", s);
            err = true;
        } else if (pass.length() < 8) {
            errs.put("pass", icon +" mot pass tres cours");
            err = true;
        }

        if (pass2 == null){
            errs.put("pass2",s);
            err = true;
        }else if (pass != null && !(pass2.equals(pass))){
            errs.put("pass2",icon + " Mot de pass non edentique ");
            err = true ;
        }

        if (err) throw new ConnectionExeption(errs);

        return !err;
    }

    @Override
    public String toString() {
        return getId() +" "+ getEmaila() +" "+ getPass() +" "+getPass2();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
