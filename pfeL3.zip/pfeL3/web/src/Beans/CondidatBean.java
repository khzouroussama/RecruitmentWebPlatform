package Beans;

import java.util.ArrayList;

public class CondidatBean {
    private String USERNAME;
    private InfoPersonBean infop;
    private ArrayList<DiplomeBean> dips;
    private ArrayList<ExperienceBean> exps;



    // ETAT de CONDIDAT
    private String PostChoisis = "0";

    private String juge ;

    private int ETAT_CONDIDATURE= 0 ;

    public int getETAT_CONDIDATURE() {
        return ETAT_CONDIDATURE;
    }

    public void setETAT_CONDIDATURE(int ETAT_CONDIDATURE) {
        this.ETAT_CONDIDATURE = ETAT_CONDIDATURE;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public InfoPersonBean getInfop() {
        return infop;
    }

    public void setInfop(InfoPersonBean infop) {
        this.infop = infop;
    }

    public ArrayList<DiplomeBean> getDips() {
        return dips;
    }

    public ArrayList<String> getDipsNames(){
        ArrayList<String> dip = new ArrayList<>();
        for (DiplomeBean diplomeBean:getDips())
            dip.add(diplomeBean.getTypeDip());
        return dip;
    }

    public String getJuge() {
        return juge;
    }

    public void setJuge(String juge) {
        this.juge = juge;
    }

    public void setDips(ArrayList<DiplomeBean> dips) {
        this.dips = dips;
    }

    public ArrayList<ExperienceBean> getExps() {
        return exps;
    }

    public void setExps(ArrayList<ExperienceBean> exps) {
        this.exps = exps;
    }


    public String getPostChoisis() {
        return PostChoisis;
  }

    public void setPostChoisis(String postChoisis) {
        PostChoisis = postChoisis;
  }

    @Override
    public String toString() {
        return "{" +
            "\"USERNAME\":\"" + USERNAME + '\"' +
            ", \"infop\":" + infop +
            ", \"dips\":" + dips +
            ", \"exps\":" + exps +
            ", \"PostChoisis\":\"" + PostBean.getPosteById(getPostChoisis()).getNomPoste() +'\"'+
            ", \"juge\":\"" + juge +'\"'+
            '}';
  }
}
