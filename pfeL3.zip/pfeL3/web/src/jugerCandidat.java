import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

// ETAT s  CANDIDATURES ....
//  0 no condidature
//  1 condidature non complit
//  2 condidature complit
//  3 condaditurr COMMITE  @ Annuler
//  4 candidature valider  RH( == en traitement )
//  5 candidature accepter ADMIN
//  6 candidature refuser

@WebServlet(name = "jugerCandidat")
public class jugerCandidat extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
            if (AdminTools.isRH_ADMIN(request)){
                UtilisateurOperations.jugerCANDIDAT(
                        (String)request.getSession().getAttribute("CONNECTED_USER"),
                        request.getParameter("user"),
                        Integer.parseInt(request.getParameter("sbt")) == 1 ? 4 : 6
                );
                response.sendRedirect("/RH/index?t="+(Integer.parseInt(request.getParameter("sbt"))));
            }
            else
                response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
        else response.sendRedirect("/login");

    }
}

