import Beans.PostBean;
import Beans.UtilisateurBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AjouterPoste")
public class AjouterPoste extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // boucoup de travaille

        PostBean postBean= new PostBean(){{
            setNumPoste(request.getParameter("poste_num"));
            setNomPoste(request.getParameter("poste_name"));
            if (request.getParameter("poste_type") != null)
                if (Integer.parseInt(request.getParameter("poste_type")) < 2 && Integer.parseInt(request.getParameter("poste_type")) > -1)
                    setTypePost(PostBean.TYPE_POSTE.values()[Integer.parseInt(request.getParameter("poste_type"))]);
            setSpecialite(request.getParameter("poste_specialite"));
            setDiploms(request.getParameter("poste_dips").split("-"));
        }};

        try {
            UtilisateurOperations.ajouterPoste(postBean);
            PostBean.POSTES_RECHERCHE = UtilisateurOperations.getPostes(PostBean.TYPE_POSTE.RECHERCHE);
            PostBean.POSTES_SOUTIEN_RECHERCHE = UtilisateurOperations.getPostes(PostBean.TYPE_POSTE.S_RECHERCHE);
        } catch (ConnectionExeption connectionExeption) {
            connectionExeption.printStackTrace();
        }

        response.sendRedirect("gestionOffres");


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
