import Beans.CondidatBean;
import Beans.PostBean;
import Connections.UtilisateurOperations;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(name = "index")
public class addPoste extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (!UtilisateurOperations.isPlateformeActif()){
            request.getRequestDispatcher("WEB-INF/nonActivePage.jsp").forward(request,response);
            return;
        }

        System.out.println(request.getParameter("choix"));

        switch (request.getParameter("sbt")) {
            case "1":
          /*
          else if (!(Boolean) request.getSession().getAttribute("COMPLETE_CONDIDATURE"))
          request.getSession().setAttribute("ERR1", "<i class=\"fas fa-info-circle\t\"></i>Vous devez soumettre votre Condidature");
            */
                if (request.getSession().getAttribute("CONNECTED_USER") == null) {
                    request.getSession().setAttribute("ERR1", "<i class=\"fas fa-info-circle\t\"></i>Vous devez etre connectée");
                    response.sendRedirect("/index");

                } else {
                    // Soumetre la CONDUDATURE
                    UtilisateurOperations.soumettreChoix(
                            (String) request.getSession().getAttribute("CONNECTED_USER"),
                            request.getParameter("choix"),
                            1
                    );
                    //TODO 3awed index1 wmis a joure l objet condidt bel post jdid
                    ((CondidatBean) request.getSession().getAttribute("CONDIDAT"))
                            .setPostChoisis(request.getParameter("choix"));
                    ((CondidatBean) request.getSession().getAttribute("CONDIDAT"))
                            .setETAT_CONDIDATURE(1);
                    response.sendRedirect("/soumettrecondidature");
                }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!UtilisateurOperations.isPlateformeActif()){
            request.getRequestDispatcher("WEB-INF/nonActivePage.jsp").forward(request,response);
            return;
        }

        request.getSession().setAttribute("RHpos", 0);
        request.getRequestDispatcher("WEB-INF/index.jsp").forward(request, response);
    }
}
