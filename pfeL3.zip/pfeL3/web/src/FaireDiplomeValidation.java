import Beans.CondidatBean;
import Beans.DiplomeBean;
import Beans.InfoPersonBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.Condidat;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

@WebServlet(name = "FaireDiplomeValidation")
@MultipartConfig
public class FaireDiplomeValidation extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        CondidatBean condidatBean =(CondidatBean) request.getSession().getAttribute("CONDIDAT");

        long nbDip =(long) request.getSession().getAttribute("nbDip");

        switch (request.getParameter("sbt")){
            //AJOUTER UN DIPLOME

            case "ADD":
                System.out.println("bhbhbhbh");
                //mis a jour apres l'ajout d'un diplome;
                for (int i = 1; i <= nbDip; i++)
                    Condidat.UpdateDeplome(request,i, condidatBean);

                condidatBean.getDips().add(new DiplomeBean());

                request.getSession().setAttribute("nbDip",nbDip +1);
                System.out.println(request.getSession().getAttribute("nbDip") +" Diplomes");
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                break;
            // ON CLICK ON RETURN
            case "RETURN":
                // return a l'arriere
                request.getSession().setAttribute("tab",0);
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                break;

            case "END":
                // finaliser le traitement et envoiyer les reponse
                boolean ERR = false ;
                HashMap<String,HashMap<String,String>> ERRS =new HashMap<>();
                ArrayList<DiplomeBean> DIPS = new ArrayList<>();

                for (int i = 1; i <= nbDip; i++)
                    Condidat.UpdateDeplome(request,i , condidatBean);

                if ( ! Condidat.isDiplomeOK(condidatBean)){
                    ERR = true ;
                    ERRS.put("-1",new HashMap<String, String>(){{put("dip_err",
                            " <div style=\"text-align: center;\"> <span class=\"round ouss-red-border\" style=\"padding: 5;\"><i class=\"fas fa-info-circle\"></i>  Diplômes ne correspond pas aux qualifications requises </span>  </div>\n"
                    );
                    }});
                }
                else
                for (int i = 1; i <= nbDip; i++) {

                    try {
                        // pout etre un ajout ou une modification ...
                        if    (UtilisateurOperations.ajouterDiplome(condidatBean.getDips().get( i - 1 )));
                        else  System.out.println("errAJOUTERDIPLOM");

                    } catch (ConnectionExeption connectionExeption) {
                        ERR =true ;
                        ERRS.put(String.valueOf(i),connectionExeption.getMsg_s());
                        connectionExeption.printStackTrace();
                    }

                }

                if (ERR){
                    request.getSession().setAttribute("errsDip",ERRS);
                    request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                }else {
                    request.getSession().setAttribute("tab",2);
                    response.sendRedirect("/soumettrecondidature");
                }


                System.out.println("hiqsqdi");
                break;
        }
        if (request.getParameter("sbt").startsWith("DELETE")){

            int indice_supp =(Integer.parseInt(request.getParameter("sbt").replaceFirst("DELETE","")));

            UtilisateurOperations.supprimerDiplome(
                    condidatBean.getDips().get(indice_supp).getNumDip()
            );

            condidatBean.getDips().remove(indice_supp);

            request.getSession().setAttribute("nbDip",nbDip -1);
            System.out.println(request.getSession().getAttribute("nbDip") +" remove Diplomes");
            request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (!UtilisateurOperations.isPlateformeActif()){
            request.getRequestDispatcher("WEB-INF/nonActivePage.jsp").forward(request,response);
            return;
        }

        if(request.getSession().getAttribute("CONNECTED_USER_ROLE") != null )
            if (request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("CND"))
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
            else response.getWriter().println("<h1>ERREUR</h2> Cette Page est pour les condidates .. ");
        else{
            response.sendRedirect("/login");
        }
    }



}
