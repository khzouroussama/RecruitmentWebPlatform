import Connections.UtilisateurOperations;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "gestionProfile")
public class gestionProfile extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession().getAttribute("CONNECTED_USER") == null)
            return;

        if (request.getParameter("cmnd").equals("modif_pass")){

            UtilisateurOperations.changePass((String)request.getSession().getAttribute("CONNECTED_USER") , request.getParameter("pass1") );
            response.sendRedirect("/gestionProfile?etat_modif=true");

        }
        else if (request.getParameter("cmnd").equals("modif_mail")){
            UtilisateurOperations.changeMail((String)request.getSession().getAttribute("CONNECTED_USER") , request.getParameter("mail") );
            response.sendRedirect("/gestionProfile?etat_modif_mail=true");
        }
        else
            response.sendRedirect("/gestionProfile");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null){
                request.getSession().setAttribute("RHpos",5);
                request.getRequestDispatcher("/WEB-INF/RH/gestionProfile.jsp").forward(request,response);
        }
        else response.sendRedirect("/login");
    }
}
