package AjaxResponses;

import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AjaxRecuperListeDesCondidat")
public class AjaxRecuperListeDesCondidat extends HttpServlet {

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    request.setCharacterEncoding("UTF-8");
    response.setCharacterEncoding("UTF-8");

    if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
      if (AdminTools.isRH_ADMIN(request)){
        if (AdminTools.isRH(request))
          // send the list as JSON ...
          response.getWriter().println(
                  UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(2)
          );
        else if (AdminTools.isADMIN(request)){
          if (request.getParameter("t") == null)
            response.getWriter().println(UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(4));
          else {
            switch (request.getParameter("t")) {
              case "1":
                response.getWriter().println(UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(4));
                break;
              case "2":
                response.getWriter().println(UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(6));
                break;
              case "3":
                response.getWriter().println(UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(2));
                break;
              default:
                response.getWriter().println(UtilisateurOperations.getListeCondidatsQuiSoumetLaCondidature(4));
            }
          }
        }
    } else response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
    else response.sendRedirect("/login");
  }

}
