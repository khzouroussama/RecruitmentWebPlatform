import Beans.CondidatBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.Condidat;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(name = "FairePersoValidation")
@MultipartConfig
public class FairePersoValidation extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String connected_user = (String) request.getSession().getAttribute("CONNECTED_USER");

        try {
            request.getSession().setAttribute("CONDIDAT", UtilisateurOperations.getCondidatBean(connected_user));
        } catch (ConnectionExeption connectionExeption) {
            connectionExeption.printStackTrace();
        }

        CondidatBean condidatBean =(CondidatBean) request.getSession().getAttribute("CONDIDAT");

        if (condidatBean != null)
            condidatBean.setUSERNAME(connected_user);
        else condidatBean = new CondidatBean(){{ setUSERNAME(connected_user);}};

        switch (request.getParameter("sbt")) {
            case "NEW":
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                break;
            case "RETURN":
                response.sendRedirect("/index");
                break;
            case "END":
                // INITIALISER LE CONDIDAT
                Condidat.init(condidatBean);

                condidatBean.getInfop().setUSERNAME(connected_user);

                // mis a jour de condidat avec les nouvelles entrees
                Condidat.UpdateInfoPersonBean(request,condidatBean);

                System.out.println(condidatBean.getInfop());

                //SUBMISSION A LA BASE DS DONNEE

                try {
                    if (!UtilisateurOperations.soumettreCondidature(condidatBean.getInfop())) {
                        System.out.println("hi");
                    } else System.out.println("errsouettreCondidature");


                    // AJOUTER LAATTA
                    try {
                        request.getSession().setAttribute("CONDIDAT", UtilisateurOperations.getCondidatBean(connected_user));
                    } catch (ConnectionExeption connectionExeption) {
                        connectionExeption.printStackTrace();
                    }

                    request.getSession().setAttribute("tab", 1);
                    request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);



                } catch (ConnectionExeption connectionExeption) {
                    connectionExeption.printStackTrace();
                    request.getSession().setAttribute("errsPV", connectionExeption.getMsg_s());
                    request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
                    //response.sendRedirect("soumettreCondidature.jsp");
                }
            break;
        }

    }

    // ONLY CONDIDATES
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (!UtilisateurOperations.isPlateformeActif()){
            request.getRequestDispatcher("WEB-INF/nonActivePage.jsp").forward(request,response);
            return;
        }

        if(request.getSession().getAttribute("CONNECTED_USER_ROLE") != null )
            if (request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("CND"))
                request.getRequestDispatcher("WEB-INF/soumettreCondidature.jsp").forward(request,response);
            else response.getWriter().println("<h1>ERREUR</h2> Cette Page est pour les condidates .. ");
        else{
            response.sendRedirect("/login");
        }

    }

}
