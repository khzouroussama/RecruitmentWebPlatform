import Beans.UtilisateurBean;
import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@WebServlet(name = "ADMINGenerateRH")
public class ADMINGenerateRH extends HttpServlet {



    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (! AdminTools.isADMIN(request))
            return;

        if (request.getParameter("id") == null && request.getParameter("emaila") == null)
            return;

        // Generate Password

        int length = 8;
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "abcdefghijklmnopqrstuvwxyz"
                + "0123456789";

        String pass = new Random().ints(length, 0, chars.length())
                .mapToObj(i -> "" + chars.charAt(i))
                .collect(Collectors.joining());

        UtilisateurBean user = new UtilisateurBean(){{
            setId(request.getParameter("id"));
            setEmaila(request.getParameter("emaila"));
            setRole("RH");
            setPass(pass);
            setPass2(pass);
        }};

        try {
            if (UtilisateurOperations.inscription(user)){

                request.getSession().setAttribute("inscritOK",Boolean.TRUE);
                request.getSession().setAttribute("user",user);

                response.sendRedirect("/ADMIN/generateRH");

            }else System.out.println("GENERATIONRH fail 0000 ...");
        } catch (ConnectionExeption connectionExeption) {

            request.getSession().setAttribute("inscritOK2",connectionExeption.getMsg_s());
            request.getSession().setAttribute("user",user);
            response.sendRedirect("/ADMIN/generateRH");
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
            if (AdminTools.isADMIN(request)){
                request.getRequestDispatcher("/WEB-INF/RH/ADMINGenerateRH.jsp").forward(request,response);
            }
            else
                response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
        else response.sendRedirect("/login");
    }
}
