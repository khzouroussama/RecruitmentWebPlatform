package Connections;

import Beans.*;
import Outils.Condidat;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;
import java.util.Date;

import static Outils.Condidat.Attributs.INFO_PERSONNELS;


// ETAT s  CANDIDATURES ....
//  0 no condidature
//  1 condidature non complit
//  2 condidature complit
//  3 condaditurr COMMITE  @ Annuler
//  4 candidature valider  RH( == en traitement )
//  5 candidature accepter ADMIN
//  5 candidature refuser

public class UtilisateurOperations {

    // Date de fin periode
    public static String Etat_platforme ;

    public static boolean existUser(String usrname) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM Utilisateurs " +
                            "WHERE id = ? ;"
            );
            preparedStatement.setString(1, usrname);

            boolean exists = preparedStatement.executeQuery().next();
            System.out.println(usrname + " exists" + exists);

            return (exists);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;

    }

    public static UtilisateurBean login(UtilisateurBean user) throws ConnectionExeption {
        Connection connection;
        PreparedStatement preparedStatement;

        //user.jeSuisValide();

        try {

            connection = Connections.getConnections();
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM Utilisateurs " +
                            "WHERE ( id= ?  OR Email= ? )" +
                            "AND mot_pass =?;"
            );

            preparedStatement.setString(1, user.getId());
            preparedStatement.setString(2, user.getEmaila());//DONE js code for choise email/id
            preparedStatement.setString(3, user.getPass());
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                resultSet.absolute(1);
                return new UtilisateurBean() {{
                    setId(resultSet.getString("id"));
                    setRole(resultSet.getString("role"));
                }};
            } else return null;

        } catch (SQLException e) {
            e.printStackTrace();
            throw new ConnectionExeption(e);
        }
    }

    public static boolean inscription(UtilisateurBean user ) throws ConnectionExeption {

        Connection connection;
        PreparedStatement preparedStatement;

        System.out.println(user);

        if (user.jeSuisValide()) {
///////erreur
            System.out.println("2->"+user);

            System.out.println("it contenue ...");

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "INSERT INTO Utilisateurs VALUES (?,?,?,?) ;"
                );

                preparedStatement.setString(1, user.getId());
                preparedStatement.setString(2, user.getEmaila());//TODO js code for choise email/id
                preparedStatement.setString(3, user.getPass());
                preparedStatement.setString(4, user.getRole());

                boolean b = preparedStatement.executeUpdate() == 1;
                System.out.println(b);

                return true;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
        }
        return false;
    }

    public static boolean soumettreCondidature(InfoPersonBean personBean) throws ConnectionExeption {

        Connection connection;
        PreparedStatement preparedStatement;

        System.out.println(personBean);

        if (personBean.jeSuisValide()) {

            System.out.println("c -> ...");

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "REPLACE INTO InfoPerso VALUES (?,?,?,?,?,?,?);"
                );

                preparedStatement.setString(1, personBean.getUSERNAME());
                preparedStatement.setString(2, personBean.getNom());
                preparedStatement.setString(3, personBean.getPrenom());
                preparedStatement.setString(4, personBean.getDate_n());
                preparedStatement.setString(5, personBean.getLieu_n());
                preparedStatement.setString(6, personBean.getFichierExNai());
                preparedStatement.setString(7, personBean.getFichierNationalite());


                return preparedStatement.executeUpdate() == 1;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
        }
        return false;
    }

    public static boolean ajouterDiplome(DiplomeBean diplomeBean) throws ConnectionExeption {
        Connection connection;
        PreparedStatement preparedStatement;

        System.out.println(diplomeBean);

        if (diplomeBean.jeSuisValide()) {

            System.out.println("c -> ...");

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "REPLACE INTO Diploms VALUES (?,?,?,?,?,?);"
                );


                preparedStatement.setString(1, diplomeBean.getNumDip());
                preparedStatement.setString(2, diplomeBean.getUSERNAME());
                preparedStatement.setString(3, diplomeBean.getTypeDip());
                preparedStatement.setString(4, diplomeBean.getEtablissDip());
                preparedStatement.setString(5, diplomeBean.getDateDip());
                preparedStatement.setString(6, diplomeBean.getFichierDip());


                return preparedStatement.executeUpdate() == 1;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
        }
        return false;
    }

    public static boolean ajouterExperience(ExperienceBean experienceBean) throws ConnectionExeption {
        Connection connection;
        PreparedStatement preparedStatement;

        System.out.println(experienceBean);

        if (experienceBean.jeSuisValide()) {

            System.out.println("c -> ...");

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "REPLACE INTO Experinces VALUES (? ,?,?,?,?,?);"
                );

                preparedStatement.setString(1, experienceBean.getNumExp());
                preparedStatement.setString(2, experienceBean.getUSERNAME());
                preparedStatement.setString(3, experienceBean.getEtabEx());
                preparedStatement.setString(4, experienceBean.getDateDebEx());
                preparedStatement.setString(5, experienceBean.getDateFinEx());
                preparedStatement.setString(6, experienceBean.getFichierAttEx());


                return preparedStatement.executeUpdate() == 1;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
        }
        return false;
    }

    public static boolean supprimerDiplome(String numDip) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM Diploms WHERE numDip = ?"
            );
            preparedStatement.setString(1, numDip);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean supprimerExperience(String numExp) {

        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM Experinces WHERE numExp = ?"
            );
            preparedStatement.setString(1, numExp);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static CondidatBean getCondidatBean(String username) throws ConnectionExeption {
        Connection connection;
        PreparedStatement preparedStatement;
        ResultSet resultSet;

        CondidatBean condidat = new CondidatBean();
        condidat.setUSERNAME(username);
        condidat.setInfop(new InfoPersonBean());
        condidat.getInfop().setUSERNAME(username);
        condidat.setDips(new ArrayList<>());
        condidat.setExps(new ArrayList<>());

        //user.jeSuisValide();

        try {

            connection = Connections.getConnections();
            // recuperation de post

            // ETAT s
            //  0 no condidature
            //  1 condidature non complit
            //  2 condidature complit
            //  3 condaditurr COMMITE  @ Annuler
            //  4 candidature valider  RH( == en traitement )
            //  5 candidature accepter ADMIN
            //  5 candidature refuser
            preparedStatement = connection.prepareStatement(
                    "SELECT POST_CHOISIS,ETAT FROM EtatUtilisateur " +
                            "WHERE id = ?"
            );

            preparedStatement.setString(1, username);

            if ((resultSet = preparedStatement.executeQuery()).next()){
                condidat.setPostChoisis(resultSet.getString("POST_CHOISIS"));
                condidat.setETAT_CONDIDATURE(resultSet.getInt("ETAT"));
//                condidat.setJuge(resultSet.getString("JUGE"));
            }

            //RECUPERATION DU INFO PERSONNEL
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM InfoPerso WHERE ( id= ? )"
            );

            preparedStatement.setString(1, username);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                resultSet.first();
                condidat.getInfop().setNom(resultSet.getString("nom"));
                condidat.getInfop().setPrenom(resultSet.getString("prenom"));
                condidat.getInfop().setDate_n(resultSet.getString("date_n"));
                condidat.getInfop().setLieu_n(resultSet.getString("lieu_n"));
                condidat.getInfop().setFichierExNai(resultSet.getString("fichierEN"));
                condidat.getInfop().setFichierNationalite(resultSet.getString("fichierNAT"));
            } else return null;

            //RECUPERATION DU DIPLOMES
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM Diploms WHERE ( id= ? )"
            );

            preparedStatement.setString(1, username);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                DiplomeBean diplomeBean = new DiplomeBean();
                diplomeBean.setUSERNAME(username);
                diplomeBean.setNumDip(resultSet.getString("numDip"));
                diplomeBean.setTypeDip(resultSet.getString("typeDip"));
                diplomeBean.setEtablissDip(resultSet.getString("etablissDip"));
                diplomeBean.setDateDip(resultSet.getString("dateDip"));
                diplomeBean.setFichierDip(resultSet.getString("fichierDip"));

                condidat.getDips().add(diplomeBean);
            }

            //RECUPERATION DU EXPERIENCES
            connection = Connections.getConnections();
            preparedStatement = connection.prepareStatement(
                    "SELECT * FROM Experinces WHERE ( id= ? )"
            );

            preparedStatement.setString(1, username);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                ExperienceBean experienceBean = new ExperienceBean();
                experienceBean.setUSERNAME(username);
                experienceBean.setNumExp(resultSet.getString("numExp"));
                experienceBean.setEtabEx(resultSet.getString("etabEx"));
                experienceBean.setDateDebEx(resultSet.getString("dateDebEx"));
                experienceBean.setDateFinEx(resultSet.getString("dateFinEx"));
                experienceBean.setFichierAttEx(resultSet.getString("fichierDip"));

                condidat.getExps().add(experienceBean);
            }
            return condidat;

        } catch (SQLException e) {
            e.printStackTrace();
            throw new ConnectionExeption(e);
        }

    }

    public static PostBean[] getPostes(PostBean.TYPE_POSTE type_poste) {
        try {
            PreparedStatement stm = Connections.getConnections().prepareStatement(
                    "SELECT * FROM Postes WHERE TypePoste = ? ;"
            );
            stm.setString(1, type_poste.name());

            ResultSet resultSet = stm.executeQuery();
            ArrayList<PostBean> postBeans = new ArrayList<>();
            while (resultSet.next()) {
                postBeans.add(
                        new PostBean() {{
                            setNumPoste(resultSet.getString("numPost"));
                            setNomPoste(resultSet.getString("nomPoste"));
                            setSpecialite(resultSet.getString("Specialite"));
                            setDiscription(resultSet.getString("Discription"));
                            setTypePost(type_poste); //
                            setDiploms(resultSet.getString("Diplomes").split("-"));
                        }}
                );
            }
            System.out.println(postBeans);
            return postBeans.toArray(new PostBean[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void soumettreChoix(String usrName, String numPost, int etat) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "REPLACE INTO EtatUtilisateur VALUES ( ? , ? , ? , '')  "
            );
            preparedStatement.setString(1, usrName);
            preparedStatement.setString(2, numPost);
            preparedStatement.setInt(3, etat);

            boolean b = preparedStatement.executeUpdate() == 1;
            System.out.println("Post [" + numPost + "] ajouter [" + b + "] a ->" + usrName +"|ETAT->"+etat);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<CondidatBean> getListeCondidatsQuiSoumetLaCondidature(int etat) {
        ArrayList<CondidatBean> condidatBeans = new ArrayList<>();
        try {
            PreparedStatement stm = Connections.getConnections().prepareStatement(
                    "SELECT * FROM EtatUtilisateur WHERE ETAT = ?;"
            );

            stm.setInt(1,etat);

            ResultSet resultSet = stm.executeQuery();
            while (resultSet.next()) {
                CondidatBean condidatBean = getCondidatBean(resultSet.getString("id"));
                condidatBean.setPostChoisis(resultSet.getString("POST_CHOISIS"));
                condidatBean.setJuge(resultSet.getString("JUGE"));
                condidatBeans.add(condidatBean);
            }
            return condidatBeans;
        } catch (SQLException | ConnectionExeption e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void jugerCANDIDAT(String juge,String candidat,int res){
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "UPDATE EtatUtilisateur set ETAT = ? ,  JUGE = ? WHERE id = ?"
            );
            preparedStatement.setInt(1, res);
            preparedStatement.setString(2, juge);
            preparedStatement.setString(3, candidat);


            boolean b = preparedStatement.executeUpdate() == 1;
            System.out.println("juge  [" + juge + "] juger [" + candidat +"|res->"+res);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static String getFichier(String id, String type) {
        Connection connection = Connections.getConnections();
        PreparedStatement stm = null;
        String fichier_trouver = null;
        System.out.println(id + "-" + type);
        try {
            switch (type) {
                case "EN":
                    stm = connection.prepareStatement("SELECT fichierEN FROM InfoPerso WHERE id = ? ;");
                    break;
                case "NAT":
                    stm = connection.prepareStatement("SELECT fichierNAT FROM InfoPerso WHERE id = ? ;");
                    break;
                case "DIP":
                    stm = connection.prepareStatement("SELECT fichierDip FROM Diploms WHERE numDip = ? ;");
                    break;
                case "EXP":
                    stm = connection.prepareStatement("SELECT fichierDip FROM Experinces WHERE numExp = ? ;");
                    break;
            }
            stm.setString(1, id);
            ResultSet result = stm.executeQuery();
            if (result.next())
                fichier_trouver =
                        result.getString(1);
            System.out.println(fichier_trouver);
            return fichier_trouver;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }



    public static boolean ajouterPoste(PostBean postBean) throws ConnectionExeption {
        Connection connection;
        PreparedStatement preparedStatement;

        System.out.println(postBean);

        if (postBean.jeSuisValide()) {

            System.out.println("c -> ...");

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "REPLACE INTO Postes VALUES (? ,?,?,?,?,?);"
                );

                preparedStatement.setString(1, postBean.getNumPoste());
                preparedStatement.setString(2, postBean.getNomPoste());
                preparedStatement.setString(3, postBean.getTypePost().toString());
                preparedStatement.setString(4, postBean.getDiscription());
                preparedStatement.setString(5, postBean.getSpecialite());
                preparedStatement.setString(6, String.join("-", postBean.getDiploms()));


                return preparedStatement.executeUpdate() == 1;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
        }
        return false;
    }

    public static boolean deletePoste(int num_poste) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM Postes WHERE numPost = ?"
            );
            preparedStatement.setInt(1, num_poste);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean deleteUser(String id) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM Utilisateurs WHERE id = ? "
            );
            preparedStatement.setString(1, id);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean changePass(String id, String pass) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "UPDATE Utilisateurs SET mot_pass = ? WHERE id = ? "
            );
            preparedStatement.setString(1, pass);
            preparedStatement.setString(2, id);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean changeMail(String id, String mail) {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "UPDATE Utilisateurs SET Email = ? WHERE id = ? "
            );
            preparedStatement.setString(1, mail);
            preparedStatement.setString(2, id);
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    /////////////////////
/// Operation de admin

    public static final int per_page = 10;

    public static int pageCountCND() {
        int count = countUsersCND();
        return count / per_page + (count % per_page == 0 ? 0 : 1);
    }

    public static int pageCountRH() {
        int count = countUsersRH();
        return count / per_page + (count % per_page == 0 ? 0 : 1);
    }

    //  TESTED
    public static int countUsersCND() {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "SELECT COUNT(*) FROM Utilisateurs " +
                            "WHERE role = 'CND' ;"
            );

            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();

            int count = resultSet.getInt(1);
            System.out.println("|-> NB de CNDs =" + count);

            return count;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }


    public static int countUsersRH() {
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "SELECT COUNT(*) FROM Utilisateurs " +
                            "WHERE role = 'RH' ;"
            );
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();

            int count = resultSet.getInt(1);
            System.out.println("|-> NB de RHs =" + count);

            return count;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }


    public static ArrayList<UtilisateurBean> getUserPageCND(int page) {
        //chaque page contien 10  utilisitateurs
        int count = countUsersCND();

        if (page > (count / per_page + (count % per_page == 0 ? 0 : 1)))
            page = count / per_page + (count % per_page == 0 ? 0 : 1);

        if (page < 1)
            page = 1;

        int start = (page - 1) * per_page;

        try {
            PreparedStatement stm = Connections.getConnections().prepareStatement(
                    "SELECT id,Email,role FROM Utilisateurs WHERE role = 'CND' LIMIT ? , ? ;"
            );
            stm.setInt(1, start);
            stm.setInt(2, per_page);

            ResultSet resultSet = stm.executeQuery();
            ArrayList<UtilisateurBean> users = new ArrayList<>();
            while (resultSet.next()) {
                users.add(
                        new UtilisateurBean() {{
                            setId(resultSet.getString("id"));
                            setEmaila(resultSet.getString("Email"));
                            setRole(resultSet.getString("role"));
                        }}
                );
            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;

    }

    public static ArrayList<UtilisateurBean> getUserPageRH(int page) {
        //chaque page contien 10  utilisitateurs
        int count = countUsersRH();

        if (page > (count / per_page + (count % per_page == 0 ? 0 : 1)))
            page = count / per_page + (count % per_page == 0 ? 0 : 1);

        if (page < 1)
            page = 1;


        int start = (page - 1) * per_page;

        try {
            PreparedStatement stm = Connections.getConnections().prepareStatement(
                    "SELECT id,Email,role FROM Utilisateurs WHERE role = 'RH' LIMIT ? , ? ;"
            );
            stm.setInt(1, start);
            stm.setInt(2, per_page);

            ResultSet resultSet = stm.executeQuery();
            ArrayList<UtilisateurBean> users = new ArrayList<>();
            while (resultSet.next()) {
                users.add(
                        new UtilisateurBean() {{
                            setId(resultSet.getString("id"));
                            setEmaila(resultSet.getString("Email"));
                            setRole(resultSet.getString("role"));
                        }}
                );
            }
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;

    }


    public static boolean isPlateformeActif() {
        String deb ;
        String fin ;
        System.out.println("----> isPlateformeActif()   ENtered   1");

        try {
            PreparedStatement stm = Connections.getConnections().prepareStatement(
                    "SELECT dateDebut,dateFin FROM EtatPlateforme WHERE numPL = 1;"
            );

            ResultSet resultSet = stm.executeQuery();
            ArrayList<UtilisateurBean> users = new ArrayList<>();
            if (resultSet.next()) {
                deb = resultSet.getString("dateDebut");
                fin = resultSet.getString("dateFin");
                Etat_platforme = fin ;
                System.out.println("----> isPlateformeActif()   ENtered   2" +deb+"----" +fin);

            }else return false;

            Date dateDeb =DateFormat.getDateInstance(DateFormat.SHORT,Locale.CANADA)
                    .parse(deb);
            Date dateFin =DateFormat.getDateInstance(DateFormat.SHORT,Locale.CANADA)
                    .parse(fin);


            System.out.println("----> isPlateformeActif()   ENtered   3" +dateDeb+"----" +dateFin);

            if (new Date().before(dateFin)  && new Date().after(dateDeb))
                return true;
            else return false;

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            System.out.println("[PLATEFORME]->Erreur de Format de date ");
            e.printStackTrace();
        }
        return false;
    }


    public static boolean setPlateformePeriode(String dateDeb,String dateFin) throws ConnectionExeption, ParseException {


            Date DateDeb =DateFormat.getDateInstance(DateFormat.SHORT,Locale.CANADA)
                    .parse(dateDeb);
            Date DateFin =DateFormat.getDateInstance(DateFormat.SHORT,Locale.CANADA)
                    .parse(dateFin);
            if (DateFin.before(DateDeb))
                return false;



        Connection connection;
        PreparedStatement preparedStatement;

            try {
                connection = Connections.getConnections();
                preparedStatement = connection.prepareStatement(
                        "REPLACE INTO EtatPlateforme VALUES (1,?,?);"
                );

                preparedStatement.setString(1, dateDeb);
                preparedStatement.setString(2, dateFin);

                return preparedStatement.executeUpdate() == 1;

            } catch (SQLException e) {
                e.printStackTrace();
                throw new ConnectionExeption(e);
            }
    }

    public static boolean deleteAllUsers(){
        Connection connection;
        PreparedStatement preparedStatement;

        connection = Connections.getConnections();
        try {
            preparedStatement = connection.prepareStatement(
                    "DELETE FROM Utilisateurs WHERE role='CND'"
            );
            return preparedStatement.executeUpdate() == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


}



