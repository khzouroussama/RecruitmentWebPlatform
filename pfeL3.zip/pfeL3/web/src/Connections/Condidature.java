package Connections;

public class Condidature {
}
