package Connections;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;

public class ConnectionExeption extends Exception {
    private String msg ;
    private HashMap<String,String> msg_s;

    public ConnectionExeption(SQLException s) {
        setMsg_s(new HashMap<>());
        if (s instanceof SQLIntegrityConstraintViolationException)
            msg_s.put("id" , "Deja exists ....." );
        else
            this.msg = "ErrEur de Connections .";
    }

    public ConnectionExeption(HashMap<String, String> msg_s) {
        this.msg_s = msg_s;
    }

    public ConnectionExeption(String mesg) {
            this.msg = mesg ;
    }

    public HashMap<String, String> getMsg_s() {
        return msg_s;
    }

    public void setMsg_s(HashMap<String, String> msg_s) {
        this.msg_s = msg_s;
    }

    @Override
    public String getMessage() {
        return msg_s.toString();
    }
}
