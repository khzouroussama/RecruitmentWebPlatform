import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "extra")
public class extra extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getParameter("q") == null)
            request.getRequestDispatcher("/WEB-INF/RH/about.jsp").forward(request,response);
        else if (request.getParameter("q").equals("about"))
            request.getRequestDispatcher("/WEB-INF/RH/about.jsp").forward(request,response);
        else if (request.getParameter("q").equals("faq"))
            request.getRequestDispatcher("/WEB-INF/RH/faq.jsp").forward(request,response);
        else if (request.getParameter("q").equals("contact"))
            request.getRequestDispatcher("/WEB-INF/RH/contact.jsp").forward(request,response);
    }
}
