import Connections.ConnectionExeption;
import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;

@WebServlet(name = "GestionPlateforme")
public class GestionPlateforme extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (! AdminTools.isADMIN(request))
            return;

        if ( request.getParameter("date_deb") != null && request.getParameter("date_fin") != null){

            try {
                UtilisateurOperations.setPlateformePeriode(
                        request.getParameter("date_deb") ,
                        request.getParameter("date_fin")
                );
                response.sendRedirect("/ADMIN/gestionPlateforme");
            } catch (ConnectionExeption connectionExeption) {
                connectionExeption.printStackTrace();
                response.sendRedirect("/ADMIN/gestionPlateforme?err=true");
            } catch (ParseException e) {
                e.printStackTrace();
                response.sendRedirect("/ADMIN/gestionPlateforme?err=true");
            }

        }else response.sendRedirect("/ADMIN/gestionPlateforme?err=true");


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
            if (AdminTools.isADMIN(request)){
                request.getSession().setAttribute("RHpos",4);
                request.getRequestDispatcher("/WEB-INF/RH/ADMINGestionPlateforme.jsp").forward(request,response);
            }
            else
                response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
        else response.sendRedirect("/login");
    }
}
