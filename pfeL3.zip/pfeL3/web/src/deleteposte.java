import Beans.PostBean;
import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "deleteposte")
public class deleteposte extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //verifier les priveliges
        if (! AdminTools.isRH_ADMIN(request))
            return;


        int num_poste = -1 ;
        String num_poste_s = request.getParameter("num");
        if (num_poste_s != null)
            num_poste = Integer.parseInt(num_poste_s);

        UtilisateurOperations.deletePoste(num_poste);
        PostBean.POSTES_RECHERCHE = UtilisateurOperations.getPostes(PostBean.TYPE_POSTE.RECHERCHE);
        PostBean.POSTES_SOUTIEN_RECHERCHE = UtilisateurOperations.getPostes(PostBean.TYPE_POSTE.S_RECHERCHE);
        response.sendRedirect("gestionOffres");

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
