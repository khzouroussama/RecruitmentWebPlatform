import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "RHGestionOffres")
public class RHGestionOffres extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if (request.getSession().getAttribute("CONNECTED_USER_ROLE") != null)
            if (AdminTools.isRH_ADMIN(request)){
                request.getSession().setAttribute("RHpos",2);
                request.getRequestDispatcher("/WEB-INF/RH/gestionOffres.jsp").forward(request,response);
            }
            else
                response.getWriter().println("<h1>ERREUR<h1/><h3>VOUS N'AVEZ PAS l'acces a cette Page</h3>");
        else response.sendRedirect("/login");
    }
}
