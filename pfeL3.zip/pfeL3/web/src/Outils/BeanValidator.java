package Outils;

import Connections.ConnectionExeption;

public interface BeanValidator {

    boolean jeSuisValide() throws ConnectionExeption;

}
