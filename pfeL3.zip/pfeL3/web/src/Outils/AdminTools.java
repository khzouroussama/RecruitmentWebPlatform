package Outils;

import javax.servlet.http.HttpServletRequest;

public class AdminTools {

    public static boolean isRH_ADMIN(HttpServletRequest request){
        return request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("RH") ||
                request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("ADMIN");
    }

    public static boolean isRH(HttpServletRequest request){
        return request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("RH");
    }

    public static boolean isADMIN(HttpServletRequest request){
        return request.getSession().getAttribute("CONNECTED_USER_ROLE").equals("ADMIN");
    }
}
