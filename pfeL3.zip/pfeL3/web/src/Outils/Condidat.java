package Outils;

import Beans.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

public class Condidat {

    public enum
    Attributs{
        INFO_PERSONNELS,
        DIPLOMS,
        EXPERIENCES
    }

    /**
     * Create if not exist
     */


    public static void init(CondidatBean condidatBean){

        if (condidatBean.getInfop() == null)
            condidatBean.setInfop(new InfoPersonBean());
        if (condidatBean.getDips() == null)
            condidatBean.setDips(new ArrayList<>());
        if (condidatBean.getExps() == null)
            condidatBean.setExps(new ArrayList<>());
    }

    public static void UpdateInfoPersonBean(HttpServletRequest req,CondidatBean condidat) throws ServletException, IOException {

        condidat.getInfop().setNom(req.getParameter("nom"));
        condidat.getInfop().setPrenom(req.getParameter("prenom"));
        condidat.getInfop().setDate_n(req.getParameter("date_n"));
        condidat.getInfop().setLieu_n(req.getParameter("lieu_n"));
        // Ajouter les fichies
        // maj des fichier ssi est nouveau
        String fichEN = fichiersCondidat
                (req, "fichierEN", condidat,Attributs.INFO_PERSONNELS);
        String fichNat = Condidat.fichiersCondidat
                (req, "fichierNationalite", condidat,Attributs.INFO_PERSONNELS);
        if (fichEN != null)
            condidat.getInfop().setFichierExNai(fichEN);
        if (fichNat != null)
            condidat.getInfop().setFichierNationalite(fichNat);
    }

    public static void UpdateDeplome(HttpServletRequest req, int index, CondidatBean condidat) throws ServletException, IOException {
        DiplomeBean dbean =condidat.getDips().get( index - 1 ) ; // l'index commence par 1 en HTML

        dbean.setUSERNAME((String) req.getSession().getAttribute("CONNECTED_USER"));
        dbean.setTypeDip(req.getParameter("typeDip"+index));
        dbean.setEtablissDip(req.getParameter("etablissDip"+index));
        dbean.setDateDip(req.getParameter("dateDip"+index));
        String fichierDip = fichiersCondidat
                (req, "fichierDip"+index, condidat,Attributs.DIPLOMS);
        if (fichierDip != null)
            dbean.setFichierDip(fichierDip);
    }

    public static void UpdateExperience(HttpServletRequest req,int index, CondidatBean condidat) throws ServletException, IOException {
        ExperienceBean exp_bean =condidat.getExps().get( index - 1);
        exp_bean.setUSERNAME((String) req.getSession().getAttribute("CONNECTED_USER"));
        exp_bean.setEtabEx(req.getParameter("etabEx"+index));
        exp_bean.setDateDebEx(req.getParameter("dateDebEx"+index));
        exp_bean.setDateFinEx(req.getParameter("dateFinEx"+index));
        String fichierAttEx = fichiersCondidat
                (req, "fichierAttEx"+index, condidat,Attributs.EXPERIENCES);
        if (fichierAttEx != null)
            exp_bean.setFichierAttEx(fichierAttEx);
    }




    /**
     * recuperer le fichier a partire d'un request est assossier le a un condidat
     * c'il exist deja elle return le chemin sont Re_sauvgarder
     *
     * @param req          le request http
     * @param attFichier   l'attribut name dans la form html
     * @param condidatBean le Bean du condidat conserne
     * @param typeFichier  le type de fichier de type {@link Attributs}
     * @return le chemin de fichier dans le serveur
     * @throws ServletException
     * @throws IOException
     */

    public static String
    fichiersCondidat(HttpServletRequest req , String attFichier , CondidatBean condidatBean,Attributs typeFichier )
            throws ServletException, IOException {

        Part filepart= req.getPart(attFichier);
        String nomFiche = Paths.get(filepart.getSubmittedFileName()).getFileName().toString();

        if (!nomFiche.isEmpty()){

            String chemin =
                    "//home//oussama3//DATA_rec//"+condidatBean.getUSERNAME()+"//"+typeFichier+"//"+attFichier+"//" ;
            try {
                new File(chemin).mkdirs();
                Files.copy(filepart.getInputStream(), new File(chemin+nomFiche).toPath());

            } catch (FileAlreadyExistsException e) { /* RIEN; */ }

            return chemin+nomFiche ;

        } else return null;

    }


    public static boolean isDiplomeOK(CondidatBean condidat) {
        String[] dips_requis = PostBean.getPosteById( condidat.getPostChoisis() ).getDiploms();
        ArrayList<DiplomeBean> dips_avis   = condidat.getDips();

        boolean compitant = false ;

        for(DiplomeBean d : dips_avis)
            for (String s1: dips_requis)
                compitant = s1.equals(d.getTypeDip()) || compitant;

        System.out.println("--->IS DIPLOME OK = "+compitant);

        return compitant;
    }

    public static String isExperienceOK(Condidat condidat){
        return null;
    }





}
