import Connections.UtilisateurOperations;
import Outils.AdminTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AdminDeleteUser")
public class AdminDeleteUser extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getSession().getAttribute("CONNECTED_USER") == null)
            return;

        String id ;

        if ((id = request.getParameter("id")) != null){
            // cas de admin
            if (! AdminTools.isADMIN(request))
                return;

            UtilisateurOperations.deleteUser(id);
            response.sendRedirect("ADMINGestionComptes?role=CND&page=1");
        }
        else if ((id = request.getParameter("tout")) != null){
            // cas de admin
            if (! AdminTools.isADMIN(request))
                return;
            if (UtilisateurOperations.deleteAllUsers())
                response.sendRedirect("/ADMIN/gestionPlateforme?init=true");
            else response.sendRedirect("/ADMIN/gestionPlateforme?init=false");
        }
        else if (! AdminTools.isADMIN(request)){
            UtilisateurOperations.deleteUser((String) request.getSession().getAttribute("CONNECTED_USER"));
            response.sendRedirect("/logout");
        }
        else response.sendRedirect("/gestionProfile");


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
